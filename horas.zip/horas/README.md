# Horas · quanto prometer de prazo de entrega

Calibração da promessa de prazo de entrega com regressão quantílica, testada fora da amostra, mais gráfico de controle pra monitorar e o desenho do teste A/B que mede o efeito na conversão.

Página do projeto: https://gabigattirodrigues.github.io/horas/

## O que tem aqui

- `horas_promessa_de_entrega.ipynb`: a análise completa (diagnóstico, custo do atraso, gráfico de controle, backtest, comparação por UF, nota esperada)
- `scripts/exportar_pagina.py`: roda o notebook e grava os números na página. Nenhum número da página é digitado à mão
- `site/`: a página publicada no GitHub Pages

## Como rodar

1. Baixar a base pública da Olist (Brazilian E-Commerce Public Dataset, no Kaggle ou em github.com/olist/work-at-olist-data) e colocar os CSVs em `data/`
2. `pip install -r requirements.txt`
3. Abrir e rodar o notebook
4. Pra atualizar a página: `python scripts/exportar_pagina.py`

## Principais resultados (jan a ago/2018, fora da amostra)

- Com a mesma taxa no prazo da promessa atual (~91%), a regressão quantílica promete cerca de 1 dia a menos na média
- O ganho maior está por estado: SP e MG recebem 2 dias a menos, RJ, BA e Nordeste recebem promessa mais longa, e a diferença de pontualidade entre estados cai 54%
- Atraso de 8+ dias leva 79% das notas pra 1 ou 2. Chegar muito antes do prometido não melhora a nota

Dados: Olist (CC BY-NC-SA 4.0). Pintura: *Horae Serenae*, Edward John Poynter (1894), domínio público.

---

# Horas · how long should a delivery promise be

Delivery-promise calibration with quantile regression, tested out of sample, plus a control chart for monitoring and the A/B test design that measures the effect on conversion. See the project page for the full case in English.
