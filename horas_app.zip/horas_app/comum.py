"""Coisas que todas as páginas usam: idioma, cores, leitura dos artefatos e formatação."""
import json
from pathlib import Path

import lightgbm as lgb
import pandas as pd
import streamlit as st

RAIZ = Path(__file__).resolve().parent.parent
ART = RAIZ / "artifacts"
ASSETS = RAIZ / "assets"

AZUL = "#1f5fbf"
AZUL_CLARO = "#9dbbe6"
AZUL_FUNDO = "#e8f0fb"
CINZA = "#8a96a3"
CINZA_CLARO = "#d7e0ea"
VERMELHO = "#c0392b"
VERDE = "#1b7a47"
TINTA = "#10233a"

LINKS = {
    "davinci": "https://testeabdesenho.streamlit.app",
    "michelangelo": "https://testeabmensuracao.streamlit.app",
    "dashboard": "https://dashboardinteligente.streamlit.app",
    "github": "https://github.com/GabiGattiRodrigues/horas",
    "notebook": "https://nbviewer.org/github/GabiGattiRodrigues/horas/blob/main/horas_promessa_de_entrega.ipynb",
}


def L(pt: str, en: str) -> str:
    """Texto em português ou inglês, conforme o idioma escolhido na barra lateral."""
    return en if st.session_state.get("lang") == "en" else pt


def lang() -> str:
    return st.session_state.get("lang", "pt")


def pct(v: float, casas: int = 1) -> str:
    s = f"{v * 100:.{casas}f}%"
    return s if lang() == "en" else s.replace(".", ",")


def num(v: float, casas: int = 0) -> str:
    s = f"{v:,.{casas}f}"
    if lang() == "en":
        return s
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def dias(v: float, casas: int = 0) -> str:
    return num(v, casas) + (" days" if lang() == "en" else " dias")


VARIAVEIS_NOME = {
    "km": ("distância vendedor → cliente (km)", "seller → customer distance (km)"),
    "seller_state": ("UF do vendedor", "seller state"),
    "customer_state": ("UF do cliente", "customer state"),
    "dia_semana": ("dia da semana da compra", "purchase weekday"),
    "frete": ("valor do frete (R$)", "freight value (R$)"),
    "peso": ("peso do pedido (g)", "order weight (g)"),
    "qtd_itens": ("itens no pedido", "items in the order"),
    "vend_manuseio_mediana": ("dias que o vendedor costuma levar pra despachar", "days the seller usually takes to ship"),
    "vend_manuseio_p90": ("dias de despacho do vendedor nos piores casos (P90)", "seller's shipping days in the worst cases (P90)"),
    "vend_pedidos": ("pedidos do vendedor no histórico", "seller's orders in history"),
}

DIAS_SEMANA = (["seg", "ter", "qua", "qui", "sex", "sáb", "dom"], ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])


def nome_var(v: str) -> str:
    pt, en = VARIAVEIS_NOME.get(v, (v, v))
    return L(pt, en)


@st.cache_data
def resultados() -> dict:
    return json.loads((ART / "resultados.json").read_text(encoding="utf-8"))


@st.cache_data
def metodo() -> dict:
    return json.loads((ART / "metodo.json").read_text(encoding="utf-8"))


@st.cache_data
def arvores() -> pd.DataFrame:
    return pd.read_csv(ART / "arvores.csv")


@st.cache_data
def arvore_didatica() -> pd.DataFrame:
    return pd.read_csv(ART / "arvore_didatica.csv")


@st.cache_data
def importancia() -> pd.Series:
    return pd.read_csv(ART / "importancia.csv", index_col=0)["ganho"]


@st.cache_data
def pedidos() -> pd.DataFrame:
    return pd.read_csv(ART / "pedidos_ago2018.csv")


@st.cache_resource
def modelo() -> lgb.Booster:
    return lgb.Booster(model_file=str(ART / "modelo_ago2018.txt"))


def matriz_modelo(linhas: pd.DataFrame) -> pd.DataFrame:
    """Monta as variáveis no formato que o modelo espera (UFs como categoria, na mesma ordem do treino)."""
    m = metodo()
    X = linhas[m["variaveis"]].copy()
    for c in ["seller_state", "customer_state"]:
        X[c] = X[c].astype(pd.CategoricalDtype(m["categorias"][c]))
    return X


def layout(fig, altura: int = 420, **kw):
    """Visual padrão dos gráficos: fundo branco, fonte da página, legenda em cima."""
    padrao = dict(
        template="plotly_white", height=altura, paper_bgcolor="white", plot_bgcolor="white",
        font=dict(family="sans-serif", size=13, color=TINTA),
        margin=dict(l=10, r=10, t=40, b=10),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
    )
    fig.update_layout(**{**padrao, **kw})
    return fig


def rodape():
    st.divider()
    st.caption(L(
        "Gabriela Gatti Rodrigues · Dados públicos da Olist (CC BY-NC-SA 4.0) · "
        "Pintura: *Horae Serenae*, Edward John Poynter (1894), domínio público.",
        "Gabriela Gatti Rodrigues · Public Olist dataset (CC BY-NC-SA 4.0) · "
        "Painting: *Horae Serenae*, Edward John Poynter (1894), public domain.",
    ))
