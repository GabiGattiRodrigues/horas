"""Capa: o problema, os números principais e o que tem em cada página."""
import streamlit as st

from horas_app.comum import ASSETS, L, LINKS, dias, num, pct, resultados, rodape

R = resultados()
Q92 = R["por_q"]["0.92"]

c1, c2 = st.columns([2, 3], vertical_alignment="center")
with c1:
    st.image(str(ASSETS / "horas.jpg"), width="stretch")
    st.caption(L(
        "*Horae Serenae*, Edward John Poynter, exposta na Royal Academy em 1894.",
        "*Horae Serenae*, Edward John Poynter, shown at the Royal Academy in 1894.",
    ))
with c2:
    st.title("Horas")
    st.markdown(L(
        "#### Quanto prometer de prazo de entrega, **pedido a pedido**.",
        "#### How long a delivery promise should be, **order by order**.",
    ))
    st.markdown(L(
        "Prometer prazo é escolher entre dois erros. Se a promessa é curta demais, o pedido atrasa e a nota cai. "
        "Se é longa demais, o pedido chega cedo, mas o cliente viu um prazo grande na hora de comprar e pode ter desistido.",
        "Promising a delivery date means choosing between two mistakes. Too short, and the order arrives late and the "
        "rating drops. Too long, and the order arrives early, but the customer saw a long lead time at checkout and "
        "may have walked away.",
    ))
    st.markdown(L(
        "Com a base pública da Olist, calibrei a promessa de cada pedido com um modelo de boosting que estima o "
        "prazo que cobre **92% das entregas parecidas**. Testei fora da amostra, mês a mês, de janeiro a agosto de 2018.",
        "Using the public Olist dataset, I calibrated each order's promise with a boosting model that estimates the "
        "lead time covering **92% of similar deliveries**. I tested it out of sample, month by month, from January to "
        "August 2018.",
    ))

st.divider()
m1, m2, m3, m4 = st.columns(4)
m1.metric(L("Pedidos analisados", "Orders analyzed"), num(R["resumo"]["pedidos"]))
m2.metric(L("Entregues no prazo hoje", "Delivered on time today"), pct(R["resumo"]["no_prazo"]))
m3.metric(L("Folga mediana", "Median slack"), dias(R["resumo"]["folga"]),
          help=L("Quantos dias antes do prometido o pedido típico chega.", "How many days before the promised date the typical order arrives."))
m4.metric(L("Diferença entre estados", "Gap between states"), "−" + pct(1 - Q92["sd_nova"] / Q92["sd_atual"], 0),
          help=L("Queda no desvio-padrão do % no prazo entre UFs, com a mesma pontualidade geral.",
                 "Drop in the standard deviation of on-time rate across states, at the same overall on-time rate."))

st.subheader(L("O que a análise mostrou", "What the analysis found"))
st.markdown(L(
    f"""
- **No total, a promessa atual já é razoável.** Pra mesma taxa no prazo, o modelo promete só cerca de 1 dia a menos.
- **O ganho está na distribuição.** SP e MG podem prometer 2 dias a menos e seguir acima de 90% no prazo. RJ, BA e o Nordeste
  precisam de uma promessa mais longa e honesta. A diferença de pontualidade entre estados cai pela metade.
- **Atraso derruba a nota, folga a mais não sobe.** Com 8 dias ou mais de atraso, quase 80% das notas são 1 ou 2.
  Chegar 8 ou 22 dias antes dá a mesma nota.
- **A base não responde o efeito na venda.** Ela só tem pedido fechado. Por isso a recomendação de encurtar vira um teste A/B.
""",
    f"""
- **Overall, the current promise is already reasonable.** At the same on-time rate, the model promises only about 1 day less.
- **The gain is in the distribution.** São Paulo and Minas Gerais can promise 2 fewer days and stay above 90% on time.
  Rio, Bahia and the Northeast need a longer, more honest promise. The on-time gap between states is cut in half.
- **Delays sink the rating, extra slack doesn't lift it.** With 8+ days of delay, almost 80% of ratings are 1 or 2 stars.
  Arriving 8 or 22 days early gets the same rating.
- **The data can't answer the effect on sales.** It only has completed orders. That's why the recommendation to shorten
  becomes an A/B test.
""",
))

st.subheader(L("Por onde começar", "Where to start"))
st.markdown(L(
    """
| Página | O que tem |
|---|---|
| 🔎 **Diagnóstico** | Onde a promessa atual sobra e onde falta, e quanto custa atrasar na nota |
| ⚖️ **Calibração** | A curva de troca entre dias prometidos e pontualidade, e o antes e depois por estado |
| 📦 **Pedido a pedido** | Um pedido real: quanto a Olist prometeu, quanto o modelo prometeria e por quê |
| 📈 **Monitoramento** | Gráfico de controle semanal, pra saber quando revisar a promessa |
| 🧪 **Teste de conversão** | O desenho do teste A/B que mede o efeito de prometer menos |
| 📚 **Como funciona** | O método explicado do zero, com exemplos e as árvores do modelo |
""",
    """
| Page | What's there |
|---|---|
| 🔎 **Diagnosis** | Where the current promise has too much slack and where it's short, and what delays cost in ratings |
| ⚖️ **Calibration** | The trade-off curve between promised days and on-time rate, and before/after by state |
| 📦 **Order by order** | A real order: what Olist promised, what the model would promise and why |
| 📈 **Monitoring** | Weekly control chart, to know when to revisit the promise |
| 🧪 **Conversion test** | The A/B test design that measures the effect of promising less |
| 📚 **How it works** | The method explained from scratch, with examples and the model's trees |
""",
))

with st.expander(L("De onde veio a ideia", "Where the idea came from")):
    st.markdown(L(
        "Nasceu de uma pergunta que ficou aberta num case de logística: quanto dá pra encurtar a promessa antes de saber o "
        "efeito na venda? Refiz do zero com base pública, sem nenhum dado de empresa. Os CSVs da Olist não ficam no "
        f"repositório. O notebook com toda a análise está no [GitHub]({LINKS['github']}).",
        "It came from a question left open in a logistics case: how much can the promise be shortened before knowing the "
        "effect on sales? I rebuilt it from scratch on public data, with no company data. The Olist CSVs aren't stored in "
        f"the repository. The notebook with the full analysis is on [GitHub]({LINKS['github']}).",
    ))

rodape()
