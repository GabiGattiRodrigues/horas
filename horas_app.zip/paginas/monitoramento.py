"""Monitoramento: gráfico de controle semanal do % no prazo."""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from horas_app.comum import AZUL, AZUL_FUNDO, CINZA, L, LINKS, VERMELHO, layout, num, pct, resultados, rodape

R = resultados()

st.title(L("📈 Monitoramento", "📈 Monitoring"))
st.markdown(L(
    "Nenhum modelo treinado no passado antecipa um choque. Por isso a promessa calibrada precisa andar junto com um "
    "monitoramento que diga quando a semana fugiu do normal.",
    "No model trained on the past sees a shock coming. That's why the calibrated promise needs monitoring that says when "
    "a week went out of normal.",
))

s = pd.DataFrame(R["semanas"])
s["dia_compra"] = pd.to_datetime(s.dia_compra)
fora = s[s.fora]

fig = go.Figure()
fig.add_scatter(x=s.dia_compra, y=s.lsc, mode="lines", line=dict(width=0), showlegend=False, hoverinfo="skip")
fig.add_scatter(x=s.dia_compra, y=s.lic, mode="lines", line=dict(width=0), fill="tonexty", fillcolor=AZUL_FUNDO,
                name=L("faixa normal (3σ)", "normal band (3σ)"), hoverinfo="skip")
fig.add_hline(y=R["p_barra"], line_dash="dot", line_color=CINZA)
fig.add_scatter(x=s.dia_compra, y=s.taxa, mode="lines+markers", line=dict(color=AZUL, width=2), marker=dict(size=4),
                name=L("% no prazo", "% on time"), customdata=s.pedidos,
                hovertemplate=L("semana de", "week of") + " %{x|%d/%m/%Y}<br>%{y:.1%}<br>" + L("pedidos", "orders") +
                              ": %{customdata:,}<extra></extra>")
fig.add_scatter(x=fora.dia_compra, y=fora.taxa, mode="markers", marker=dict(color=VERMELHO, size=11),
                name=L("fora de controle", "out of control"), hoverinfo="skip")
layout(fig, 460, yaxis_tickformat=".0%", yaxis_title=L("% no prazo", "% on time"))
st.plotly_chart(fig, width="stretch")
st.caption(L(
    f"% no prazo por semana de compra, semanas com 300 pedidos ou mais. A linha pontilhada é a média ({pct(R['p_barra'])}). "
    "A faixa azul é a variação esperada só pelo acaso, dado o volume de cada semana.",
    f"% on time by purchase week, weeks with 300+ orders. The dotted line is the average ({pct(R['p_barra'])}). The blue "
    "band is the variation expected from chance alone, given each week's volume.",
))

st.subheader(L(f"{len(fora)} semanas fora de controle", f"{len(fora)} weeks out of control"))
st.markdown(L(
    "A maioria está na Black Friday de 2017 e entre fevereiro e março de 2018. A semana de 14 de maio de 2018 "
    "provavelmente pegou a greve dos caminhoneiros com o pedido ainda em trânsito. Quando uma semana sai do limite, a "
    "promessa daquele período tem que ser revista, sem esperar a recalibração do mês.",
    "Most are in Black Friday 2017 and between February and March 2018. The week of May 14, 2018 probably caught the "
    "Brazilian truckers' strike with orders still in transit. When a week falls out of bounds, that period's promise needs "
    "review without waiting for the monthly recalibration.",
))
t = fora[["dia_compra", "pedidos", "taxa", "lic"]].copy()
t["dia_compra"] = t.dia_compra.dt.strftime("%d/%m/%Y")
t.columns = [L("semana de", "week of"), L("pedidos", "orders"), L("% no prazo", "% on time"), L("limite inferior", "lower limit")]
st.dataframe(t, hide_index=True, width="stretch", column_config={
    L("% no prazo", "% on time"): st.column_config.NumberColumn(format="percent"),
    L("limite inferior", "lower limit"): st.column_config.NumberColumn(format="percent"),
})

st.info(L(
    f"**Próximo passo:** esse monitoramento vai virar o **Vulcão**, agente de logística do "
    f"[Dashboard Inteligente]({LINKS['dashboard']}), que avisa quando a semana sai do controle e qual região puxou a queda.",
    f"**Next step:** this monitoring will become **Vulcão**, the logistics agent in the "
    f"[Intelligent Dashboard]({LINKS['dashboard']}), which flags when a week goes out of control and which region drove the drop.",
), icon="🌋")

rodape()
