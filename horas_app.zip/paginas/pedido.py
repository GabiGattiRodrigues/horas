"""Pedido a pedido: um pedido real de agosto/2018, a promessa da Olist, a do modelo e o que pesou."""
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from horas_app.comum import (AZUL, CINZA, DIAS_SEMANA, L, VERDE, VERMELHO, dias, lang, layout, matriz_modelo,
                             metodo, modelo, nome_var, num, pedidos, rodape)

M = metodo()
P = pedidos()

st.title(L("📦 Pedido a pedido", "📦 Order by order"))
st.markdown(L(
    f"Pedidos reais de agosto de 2018. O modelo que dá a promessa aqui aprendeu só com os pedidos entregues de "
    f"{M['treino_de']} a {M['treino_ate']}, então nunca viu esses pedidos. É o mesmo modelo do backtest daquele mês.",
    f"Real orders from August 2018. The model giving the promise here learned only from orders delivered between "
    f"{M['treino_de']} and {M['treino_ate']}, so it never saw these orders. It's the same model as that month's backtest.",
))


def selecionados() -> pd.DataFrame:
    """Uma lista curta de pedidos que contam a história, mais alguns casos de borda."""
    ent = P[P.prazo_real.notna()].copy()
    escolhas = []
    for rota in ["SP>SP", "SP>RJ", "SP>MG", "SP>BA", "SP>CE", "MG>SP", "PR>RS", "SP>PA"]:
        r = ent[ent.rota == rota]
        if len(r):
            alvo = r.prazo_real.median()
            escolhas.append(r.iloc[(r.prazo_real - alvo).abs().argsort()].iloc[0])
    olist_atrasou = ent[(ent.prazo_real > ent.prazo_prometido) & (ent.prazo_real <= ent.promessa_nova)].sort_values("order_id")
    modelo_atrasou = ent[(ent.prazo_real <= ent.prazo_prometido) & (ent.prazo_real > ent.promessa_nova)].sort_values("order_id")
    marcas = {}
    if len(olist_atrasou):
        escolhas.append(olist_atrasou.iloc[0])
        marcas[olist_atrasou.index[0]] = "olist"
    if len(modelo_atrasou):
        escolhas.append(modelo_atrasou.iloc[0])
        marcas[modelo_atrasou.index[0]] = "modelo"
    return pd.DataFrame(escolhas).drop_duplicates("order_id"), marcas


SEL, MARCAS = selecionados()


def rotulo(i):
    r = P.loc[i]
    rota = r.rota.replace(">", " → ")
    if pd.isna(r.prazo_real):
        return f"{rota} · {L('não chegou', 'not delivered')}"
    marca = {"olist": L(" · a Olist atrasou, o modelo não", " · Olist was late, the model wasn't"),
             "modelo": L(" · o modelo atrasaria, a Olist não", " · the model would be late, Olist wasn't")}.get(MARCAS.get(i), "")
    return f"{rota} · {L('chegou em', 'arrived in')} {dias(r.prazo_real)}{marca}"


if "pedido_idx" not in st.session_state:
    st.session_state.pedido_idx = int(SEL.index[1])

c1, c2 = st.columns([3, 1], vertical_alignment="bottom")
opcoes = list(SEL.index)
if st.session_state.pedido_idx not in opcoes:
    opcoes = [st.session_state.pedido_idx] + opcoes
idx = c1.selectbox(L("Escolha um pedido", "Pick an order"), opcoes, index=opcoes.index(st.session_state.pedido_idx),
                   format_func=rotulo)
st.session_state.pedido_idx = idx
if c2.button(L("🎲 Sortear outro", "🎲 Random order"), width="stretch"):
    st.session_state.pedido_idx = int(np.random.default_rng().choice(P.index))
    st.rerun()

p = P.loc[st.session_state.pedido_idx]
X = matriz_modelo(P.loc[[p.name]])
bruto = float(modelo().predict(X)[0])
prom_modelo = int(np.ceil(bruto))

st.divider()
a, b, c = st.columns(3)
a.metric(L("Olist prometeu", "Olist promised"), dias(p.prazo_prometido))
b.metric(L("O modelo prometeria", "The model would promise"), dias(prom_modelo),
         delta=num(prom_modelo - p.prazo_prometido) + L(" dias", " days"), delta_color="off")
if pd.isna(p.prazo_real):
    c.metric(L("Chegou em", "Arrived in"), L("não chegou", "not delivered"))
else:
    c.metric(L("Chegou em", "Arrived in"), dias(p.prazo_real))

if pd.notna(p.prazo_real):
    ok_olist = p.prazo_real <= p.prazo_prometido
    ok_mod = p.prazo_real <= prom_modelo
    txt_o = L("dentro do prazo", "on time") if ok_olist else L("atrasado", "late")
    txt_m = L("dentro do prazo", "on time") if ok_mod else L("atrasado", "late")
    st.markdown(L(
        f"Com a promessa da Olist, esse pedido ficaria **{txt_o}**. Com a promessa do modelo, ficaria **{txt_m}**.",
        f"With Olist's promise, this order would be **{txt_o}**. With the model's promise, it would be **{txt_m}**.",
    ))

with st.expander(L("Ficha do pedido", "Order details"), expanded=True):
    dia = DIAS_SEMANA[0 if lang() == "pt" else 1][int(p.dia_semana)]
    ficha = pd.DataFrame([
        (L("Rota", "Route"), f"{p.seller_city.title()} ({p.seller_state}) → {p.customer_city.title()} ({p.customer_state})"),
        (L("Compra", "Purchase"), f"{p.dia_compra} ({dia})"),
        (nome_var("km"), num(p.km)),
        (nome_var("frete"), "R$ " + num(p.frete, 2)),
        (nome_var("peso"), num(p.peso)),
        (nome_var("qtd_itens"), num(p.qtd_itens)),
        (nome_var("vend_manuseio_mediana"), "—" if pd.isna(p.vend_manuseio_mediana) else num(p.vend_manuseio_mediana, 1)),
        (nome_var("vend_manuseio_p90"), "—" if pd.isna(p.vend_manuseio_p90) else num(p.vend_manuseio_p90, 1)),
        (nome_var("vend_pedidos"), "—" if pd.isna(p.vend_pedidos) else num(p.vend_pedidos)),
    ], columns=[L("Campo", "Field"), L("Valor", "Value")])
    st.dataframe(ficha, hide_index=True, width="stretch")
    if pd.isna(p.vend_pedidos):
        st.caption(L("Vendedor sem histórico nos 6 meses anteriores: o modelo segue o caminho que o treino achou melhor pra dado ausente.",
                     "Seller with no history in the previous 6 months: the model follows the path training found best for missing data."))

st.subheader(L("Como o modelo chegou nesse número", "How the model got to this number"))
st.markdown(L(
    "O gráfico abaixo reparte a promessa entre as variáveis. Começa na promessa média que o modelo dá pros pedidos do "
    "treino. Cada barra mostra quantos dias aquela informação do pedido somou ou tirou. No fim, arredonda pra cima, "
    "porque não dá pra prometer meio dia.",
    "The chart below splits the promise across the variables. It starts at the model's average promise for training "
    "orders. Each bar shows how many days that piece of the order's information added or removed. At the end it rounds "
    "up, because you can't promise half a day.",
))

contrib = modelo().predict(X, pred_contrib=True)[0]
base, partes = contrib[-1], pd.Series(contrib[:-1], index=M["variaveis"])
ordem = partes.abs().sort_values(ascending=False).index
principais = list(ordem[:6])
resto = partes.drop(principais).sum()


def valor_legivel(v):
    x = p[v]
    if v in ("seller_state", "customer_state"):
        return str(x)
    if v == "dia_semana":
        return DIAS_SEMANA[0 if lang() == "pt" else 1][int(x)]
    if pd.isna(x):
        return "—"
    return num(x, 1 if v.startswith("vend_manuseio") else 0)


rotulos = [L("promessa média", "average promise")] + [f"{nome_var(v)} = {valor_legivel(v)}" for v in principais] + \
          [L("outras variáveis", "other variables"), L("resultado do modelo", "model output")]
valores = [base] + [partes[v] for v in principais] + [resto, bruto]
medidas = ["absolute"] + ["relative"] * (len(principais) + 1) + ["total"]
fig = go.Figure(go.Waterfall(
    orientation="h", y=rotulos, x=valores, measure=medidas,
    text=[num(base, 1)] + [("+" if v > 0 else "") + num(v, 1) for v in valores[1:-1]] + [num(bruto, 1)],
    textposition="outside",
    increasing=dict(marker=dict(color=VERMELHO)), decreasing=dict(marker=dict(color=AZUL)),
    totals=dict(marker=dict(color="#10233a")), connector=dict(line=dict(color=CINZA, width=1)),
))
acumulado = np.cumsum([base] + [partes[v] for v in principais] + [resto])
layout(fig, 460, showlegend=False, xaxis_title=L("dias", "days"),
       xaxis=dict(range=[0, max(acumulado.max(), bruto) * 1.15]))
fig.update_yaxes(autorange="reversed")
st.plotly_chart(fig, width="stretch")
st.caption(L(
    f"Vermelho soma dias, azul tira. {num(bruto, 2)} arredondado pra cima vira {prom_modelo} dias. Essa repartição é o "
    "SHAP do próprio LightGBM, explicado na página **Como funciona**.",
    f"Red adds days, blue removes them. {num(bruto, 2)} rounded up becomes {prom_modelo} days. This split is LightGBM's "
    "own SHAP, explained on the **How it works** page.",
))

st.subheader(L("Árvore por árvore", "Tree by tree"))
st.markdown(L(
    f"O modelo soma {M['n_arvores']} árvores. A primeira já começa no prazo que cobre 92% de todos os pedidos do treino "
    f"({dias(M['p92_treino'])}). Cada árvore seguinte faz um ajuste pequeno, olhando onde as anteriores erraram.",
    f"The model adds up {M['n_arvores']} trees. The first one already starts at the lead time covering 92% of all training "
    f"orders ({dias(M['p92_treino'])}). Each following tree makes a small adjustment, looking at where the previous ones went wrong.",
))
ks = [1, 2, 3, 5, 10, 15, 20, 30, 40, 50, 75, 100, 125, 150, 200, 250, M["n_arvores"]]
caminho = [float(modelo().predict(X, num_iteration=k)[0]) for k in ks]
fig = go.Figure()
fig.add_scatter(x=ks, y=caminho, mode="lines+markers", line=dict(color=AZUL, width=2.5), name=L("promessa", "promise"),
                hovertemplate=L("depois de %{x} árvores", "after %{x} trees") + ": %{y:.1f} " + L("dias", "days") + "<extra></extra>")
fig.add_hline(y=p.prazo_prometido, line_dash="dot", line_color=VERMELHO,
              annotation_text=L("Olist prometeu", "Olist promised"), annotation_position="top left")
if pd.notna(p.prazo_real):
    fig.add_hline(y=p.prazo_real, line_dash="dash", line_color=VERDE,
                  annotation_text=L("chegou em", "arrived in"), annotation_position="bottom left")
layout(fig, 380, showlegend=False, xaxis_title=L("quantidade de árvores somadas", "number of trees added"),
       yaxis_title=L("promessa (dias)", "promise (days)"))
st.plotly_chart(fig, width="stretch")

rodape()
