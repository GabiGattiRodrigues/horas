"""Diagnóstico: folga × pontualidade por estado e o custo do atraso na nota."""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from horas_app.comum import AZUL, CINZA_CLARO, L, VERMELHO, dias, layout, num, pct, resultados, rodape

R = resultados()

st.title(L("🔎 Diagnóstico", "🔎 Diagnosis"))
st.markdown(L(
    "Antes de mudar a promessa, olhando como ela se sai hoje. Pedidos que não chegaram até o fim da base contam como "
    "atrasados, porque todos já tinham passado do prazo.",
    "Before changing the promise, looking at how it performs today. Orders that hadn't arrived by the end of the data "
    "count as late, because all of them were already past due.",
))

r = R["resumo"]
c1, c2, c3, c4 = st.columns(4)
c1.metric(L("No prazo", "On time"), pct(r["no_prazo"]))
c2.metric(L("Prazo prometido (mediana)", "Promised lead time (median)"), dias(r["prometido"]))
c3.metric(L("Prazo real (mediana)", "Actual lead time (median)"), dias(r["real"]))
c4.metric(L("Prazo real (P95)", "Actual lead time (P95)"), dias(r["p95"]),
          help=L("95% dos pedidos chegaram em até esse prazo.", "95% of orders arrived within this lead time."))

st.subheader(L("A mesma folga rende pontualidades bem diferentes", "The same slack yields very different on-time rates"))
st.markdown(L(
    "Na mediana, o pedido chega bem antes do prometido. Mas a cauda é longa e muda de estado pra estado. SP tem entrega "
    "curta e atrasa pouco. RJ, BA e o Nordeste têm folga parecida na mediana, só que passam do prazo com muito mais frequência.",
    "At the median, orders arrive well before the promised date. But the tail is long and varies by state. São Paulo has "
    "short deliveries and few delays. Rio, Bahia and the Northeast have similar median slack, yet miss the date far more often.",
))

uf = pd.DataFrame(R["por_uf"])
cores = [VERMELHO if v < 0.88 else AZUL for v in uf.no_prazo]
# Estados no mesmo ponto: o menor ganha o rótulo do lado de fora, pra não sobrepor
posicoes, vistos = [], []
for r in uf.sort_values("pedidos", ascending=False).itertuples():
    perto = any(abs(r.folga_mediana - x) < 0.4 and abs(r.no_prazo - y) < 0.012 for x, y in vistos)
    posicoes.append((r.Index, "middle right" if perto else "middle center"))
    vistos.append((r.folga_mediana, r.no_prazo))
posicao = pd.Series(dict(posicoes)).reindex(uf.index)
texto = [f"   {t}" if p_ == "middle right" else t for t, p_ in zip(uf.customer_state, posicao)]
fig = go.Figure(go.Scatter(
    x=uf.folga_mediana, y=uf.no_prazo, mode="markers+text", text=texto,
    textposition=list(posicao), textfont=dict(size=11, color="#10233a"),
    marker=dict(size=uf.pedidos, sizemode="area", sizeref=2 * uf.pedidos.max() / 60 ** 2, sizemin=10,
                color=cores, opacity=0.28, line=dict(color=cores, width=1.5)),
    customdata=uf[["pedidos", "prometido_mediana", "real_mediana", "customer_state"]],
    hovertemplate="%{customdata[3]}<br>" + L("no prazo", "on time") + ": %{y:.1%}<br>" + L("folga mediana", "median slack") +
                  ": %{x} " + L("dias", "days") + "<br>" + L("pedidos", "orders") + ": %{customdata[0]:,}<extra></extra>",
))
layout(fig, 480, xaxis_title=L("folga mediana (dias)", "median slack (days)"), yaxis_title=L("% no prazo", "% on time"),
       yaxis_tickformat=".0%", showlegend=False)
st.plotly_chart(fig, width="stretch")
st.caption(L("Tamanho do círculo = volume de pedidos. Em vermelho, estados com menos de 88% no prazo. UFs com 300 pedidos ou mais.",
             "Circle size = order volume. In red, states below 88% on time. States with 300+ orders."))

with st.expander(L("Ver a tabela por UF", "See the table by state")):
    t = uf.rename(columns={"customer_state": "UF", "pedidos": L("pedidos", "orders"), "no_prazo": L("no prazo", "on time"),
                           "folga_mediana": L("folga mediana", "median slack"), "prometido_mediana": L("prometido (mediana)", "promised (median)"),
                           "real_mediana": L("real (mediana)", "actual (median)")})
    st.dataframe(t, hide_index=True, width="stretch",
                 column_config={L("no prazo", "on time"): st.column_config.NumberColumn(format="percent")})

st.subheader(L("Atraso derruba a nota. Folga a mais não sobe a nota.", "Delays sink the rating. Extra slack doesn't lift it."))
st.markdown(L(
    "Cruzando quantos dias o pedido chegou antes ou depois do prometido com a nota que o cliente deu. Com 8 dias ou mais "
    "de atraso, quase quatro em cada cinco avaliações são 1 ou 2. Do outro lado, chegar 8, 15 ou 22 dias antes dá "
    "praticamente a mesma nota. Essa folga extra não compra satisfação, só alonga o prazo que o cliente vê antes de comprar.",
    "Crossing how many days early or late the order arrived with the rating the customer gave. With 8 or more days of "
    "delay, almost four in five reviews are 1 or 2 stars. On the other side, arriving 8, 15 or 22 days early gets "
    "practically the same rating. That extra slack buys no satisfaction, it only lengthens the lead time the customer sees before buying.",
))

FAIXAS_EN = {
    "8+ dias atrasado": "8+ days late", "4 a 7 atrasado": "4–7 days late", "1 a 3 atrasado": "1–3 days late",
    "no dia": "on the day", "1 a 3 antes": "1–3 days early", "4 a 7 antes": "4–7 days early",
    "8 a 14 antes": "8–14 days early", "15 a 21 antes": "15–21 days early", "22+ antes": "22+ days early",
}
n = pd.DataFrame(R["notas"])
n["rotulo"] = n.faixa if L("pt", "en") == "pt" else n.faixa.map(FAIXAS_EN)
fig = go.Figure(go.Bar(
    x=n.rotulo, y=n.pct_nota_1_2, marker_color=[VERMELHO if "atrasado" in f else AZUL for f in n.faixa],
    error_y=dict(type="data", symmetric=False, array=n.ic_sup - n.pct_nota_1_2, arrayminus=n.pct_nota_1_2 - n.ic_inf,
                 color="#5b6776", thickness=1.2),
    customdata=n[["pedidos", "nota_media"]],
    hovertemplate="%{x}<br>" + L("notas 1 e 2", "1–2 star ratings") + ": %{y:.1%}<br>" + L("nota média", "average rating") +
                  ": %{customdata[1]:.2f}<br>" + L("pedidos", "orders") + ": %{customdata[0]:,}<extra></extra>",
))
layout(fig, 420, yaxis_tickformat=".0%", yaxis_title=L("% de notas 1 e 2", "% of 1–2 star ratings"), showlegend=False)
fig.update_yaxes(gridcolor=CINZA_CLARO)
st.plotly_chart(fig, width="stretch")
st.caption(L("A barrinha preta é o intervalo de confiança de 95% (Wilson). Não sabe o que é? Veja a página **Como funciona**.",
             "The black whisker is the 95% confidence interval (Wilson). Not sure what that is? See the **How it works** page."))

st.info(L(
    "**O que isso quer dizer pra promessa:** onde sobra folga, dá pra prometer menos sem perder nota. Onde atrasa, vale "
    "prometer mais, porque cada atraso custa caro na avaliação.",
    "**What this means for the promise:** where there's spare slack, you can promise less without losing rating. Where "
    "orders run late, it's worth promising more, because each delay is expensive in ratings.",
), icon="💡")

rodape()
