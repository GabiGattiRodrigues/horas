"""Calibração: curva de troca e antes × depois por estado, com o percentil escolhido pelo usuário."""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from horas_app.comum import AZUL, CINZA, CINZA_CLARO, L, VERDE, VERMELHO, layout, num, pct, resultados, rodape

R = resultados()
QS = ["0.85", "0.88", "0.90", "0.92", "0.94", "0.96"]

st.title(L("⚖️ Calibração", "⚖️ Calibration"))
st.markdown(L(
    "Duas formas de definir a promessa, testadas fora da amostra de janeiro a agosto de 2018. Em cada mês, o modelo só "
    "aprende com os 6 meses anteriores, como funcionaria de verdade.",
    "Two ways of setting the promise, tested out of sample from January to August 2018. Each month, the model only learns "
    "from the previous 6 months, like it would in production.",
))
c1, c2 = st.columns(2)
c1.markdown(L(
    "**Percentil por rota.** Pega os pedidos passados da mesma rota (UF do vendedor → UF do cliente) e promete o prazo que "
    "cobriu uma certa porcentagem deles.",
    "**Route percentile.** Takes past orders on the same route (seller state → customer state) and promises the lead time "
    "that covered a given share of them.",
))
c2.markdown(L(
    "**LightGBM quantílico.** Faz a mesma conta, mas olhando também distância, frete, peso, dia da compra e o histórico de "
    "despacho do vendedor.",
    "**Quantile LightGBM.** Does the same, but also looks at distance, freight, weight, purchase weekday and the seller's "
    "shipping history.",
))

st.subheader(L("No total, a promessa atual já é razoável", "Overall, the current promise is already reasonable"))
cv = pd.DataFrame(R["curva"])
fig = go.Figure()
for metodo_, nome, cor in [("rota", L("Percentil por rota", "Route percentile"), CINZA),
                           ("quantilica", L("LightGBM quantílico", "Quantile LightGBM"), AZUL)]:
    c = cv[cv.metodo == metodo_]
    fig.add_scatter(x=c.dias, y=c.no_prazo, mode="lines+markers", name=nome, line=dict(color=cor, width=2.5),
                    marker=dict(size=8), text=[f"P{round(q * 100)}" for q in c.q],
                    hovertemplate="%{text}<br>%{x:.1f} " + L("dias", "days") + "<br>%{y:.1%}<extra>" + nome + "</extra>")
o = cv[cv.metodo == "olist"].iloc[0]
fig.add_scatter(x=[o.dias], y=[o.no_prazo], mode="markers", name=L("Promessa atual (Olist)", "Current promise (Olist)"),
                marker=dict(color=VERMELHO, size=15, symbol="diamond"),
                hovertemplate="Olist<br>%{x:.1f} " + L("dias", "days") + "<br>%{y:.1%}<extra></extra>")
layout(fig, 440, xaxis_title=L("promessa média (dias)", "average promise (days)"), yaxis_title=L("% no prazo", "% on time"),
       yaxis_tickformat=".0%")
st.plotly_chart(fig, width="stretch")
st.markdown(L(
    "Cada ponto é um percentil. Quanto mais pra esquerda e pra cima, melhor: menos dias prometidos com mais pedidos no prazo. "
    "O percentil por rota empata com a Olist. O LightGBM fica um pouco acima, e economiza cerca de 1 dia pra mesma "
    "pontualidade. É pouco no agregado. O ganho de verdade aparece quando abre por estado.",
    "Each point is a percentile. Further left and higher is better: fewer promised days with more orders on time. The route "
    "percentile ties with Olist. LightGBM sits slightly above and saves about 1 day at the same on-time rate. That's little "
    "in aggregate. The real gain shows up by state.",
))

st.subheader(L("Tirar folga de quem tem sobra e dar pra quem atrasa", "Take slack from where it's spare and give it to where orders run late"))
q = st.select_slider(L("Percentil da promessa calibrada", "Percentile of the calibrated promise"), options=QS, value="0.92",
                     format_func=lambda v: f"P{round(float(v) * 100)}",
                     help=L("P92 quer dizer: prometer o prazo que 92% dos pedidos parecidos cumprem. É o que empata com a pontualidade atual.",
                            "P92 means promising the lead time that 92% of similar orders meet. It's the one that matches today's on-time rate."))
d = R["por_q"][q]
m1, m2, m3, m4 = st.columns(4)
m1.metric(L("% no prazo geral", "Overall % on time"), pct(d["geral_nova"]),
          delta=num((d["geral_nova"] - d["geral_atual"]) * 100, 1) + " p.p.")
m2.metric(L("Promessa média", "Average promise"), num(d["dias_nova"], 1) + L(" dias", " days"),
          delta=num(d["dias_nova"] - d["dias_atual"], 1) + L(" dias", " days"), delta_color="inverse")
m3.metric(L("Diferença entre estados", "Gap between states"), num(d["sd_nova"] * 100, 1) + " p.p.",
          delta=num((d["sd_nova"] - d["sd_atual"]) * 100, 1) + " p.p.", delta_color="inverse",
          help=L("Desvio-padrão do % no prazo entre as UFs com 600+ pedidos.", "Standard deviation of on-time rate across states with 600+ orders."))
m4.metric(L("Nota esperada", "Expected rating"), num(d["nota_nova"], 2), delta=num(d["nota_nova"] - d["nota_atual"], 2),
          help=L("Simulação: aplica a nota média de cada faixa de folga à folga que cada política geraria. Mostra o sentido, não é efeito causal.",
                 "Simulation: applies the average rating of each slack band to the slack each policy would produce. Shows direction, not a causal effect."))
st.caption(L("A setinha compara com a promessa atual da Olist no mesmo período.", "The arrow compares with Olist's current promise over the same period."))

u = pd.DataFrame(d["ufs"]).sort_values("no_prazo_atual")
fig = go.Figure()
for _, r in u.iterrows():
    fig.add_shape(type="line", x0=r.no_prazo_atual, x1=r.no_prazo_nova, y0=r.customer_state, y1=r.customer_state,
                  line=dict(color=CINZA_CLARO, width=4), layer="below")
fig.add_scatter(x=u.no_prazo_atual, y=u.customer_state, mode="markers", name=L("Promessa atual", "Current promise"),
                marker=dict(color=CINZA, size=13), customdata=u.promessa_atual,
                hovertemplate="%{y}: %{x:.1%}<br>" + L("promessa mediana", "median promise") + ": %{customdata} " + L("dias", "days") + "<extra></extra>")
fig.add_scatter(x=u.no_prazo_nova, y=u.customer_state, mode="markers", name=L("Promessa calibrada", "Calibrated promise"),
                marker=dict(color=AZUL, size=13), customdata=u.promessa_nova,
                hovertemplate="%{y}: %{x:.1%}<br>" + L("promessa mediana", "median promise") + ": %{customdata} " + L("dias", "days") + "<extra></extra>")
for _, r in u.iterrows():
    dd = r.dif_dias
    fig.add_annotation(x=1.0, xref="paper", y=r.customer_state, xanchor="left", showarrow=False,
                       text=(f"{dd:+.0f} d" if dd else "±0 d"), font=dict(color=VERDE if dd < 0 else "#4c6179", size=12))
fig.add_vline(x=0.90, line_dash="dash", line_color=VERDE, annotation_text="90%", annotation_position="top")
layout(fig, 520, xaxis_tickformat=".0%", xaxis_title=L("% no prazo", "% on time"), margin=dict(l=10, r=60, t=40, b=10))
st.plotly_chart(fig, width="stretch")
st.caption(L("À direita, quantos dias a promessa mediana muda em cada UF. Jan a ago/2018, UFs com 600 pedidos ou mais.",
             "On the right, how many days the median promise changes in each state. Jan–Aug 2018, states with 600+ orders."))

st.info(L(
    "**Leitura:** com o P92, SP e MG ganham 2 dias a menos de promessa e seguem acima de 90% no prazo. RJ, BA, ES, PE e CE "
    "recebem uma promessa mais longa e o atraso cai bastante. A pontualidade geral fica parecida, mas bem mais igual entre estados.",
    "**Reading:** at P92, São Paulo and Minas Gerais get 2 fewer days of promise and stay above 90% on time. Rio, Bahia, "
    "Espírito Santo, Pernambuco and Ceará get a longer promise and delays drop a lot. The overall on-time rate stays similar, "
    "but much more even across states.",
), icon="💡")

rodape()
