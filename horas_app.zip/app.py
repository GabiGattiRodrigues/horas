"""Horas: navegação entre as páginas do app."""
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

st.set_page_config(page_title="Horas · quanto prometer de prazo de entrega", page_icon="🕰️", layout="wide")

if "lang" not in st.session_state:
    st.session_state.lang = "pt"

with st.sidebar:
    st.image(str(Path(__file__).parent / "assets" / "horas.jpg"), width="stretch")
    idioma = st.radio("Idioma / Language", ["🇧🇷 Português", "🇬🇧 English"], horizontal=True,
                      index=0 if st.session_state.lang == "pt" else 1)
    st.session_state.lang = "pt" if idioma.startswith("🇧🇷") else "en"
    pt = st.session_state.lang == "pt"
    st.caption(
        "As Horas eram as deusas gregas da ordem do tempo. Aqui, elas decidem quantos dias prometer em cada pedido."
        if pt else
        "The Horae were the Greek goddesses of the order of time. Here, they decide how many days to promise on each order."
    )
    st.divider()

    paginas = [
        st.Page("paginas/inicio.py", title="Início" if pt else "Home", icon="🕰️", default=True),
        st.Page("paginas/diagnostico.py", title="Diagnóstico" if pt else "Diagnosis", icon="🔎", url_path="diagnostico"),
        st.Page("paginas/calibracao.py", title="Calibração" if pt else "Calibration", icon="⚖️", url_path="calibracao"),
        st.Page("paginas/pedido.py", title="Pedido a pedido" if pt else "Order by order", icon="📦", url_path="pedido"),
        st.Page("paginas/monitoramento.py", title="Monitoramento" if pt else "Monitoring", icon="📈", url_path="monitoramento"),
        st.Page("paginas/teste.py", title="Teste de conversão" if pt else "Conversion test", icon="🧪", url_path="teste"),
        st.Page("paginas/como_funciona.py", title="Como funciona" if pt else "How it works", icon="📚", url_path="como-funciona"),
    ]
    # position="hidden" tira o menu automático, pra imagem e idioma ficarem por cima da lista de páginas
    pg = st.navigation(paginas, position="hidden")
    for pagina in paginas:
        st.page_link(pagina)

pg.run()
